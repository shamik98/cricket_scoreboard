import React, { useState, useEffect } from 'react';
import './App.css';

const App = () => {
  const [balls, setBalls] = useState(0);
  const [overs, setOvers] = useState(0);

  useEffect(() => {
    if (balls === 7) {
      setBalls(1);
      setOvers(overs + 1);
    }
  }, [balls, overs]);

  const handleBallIncrement = () => {
    setBalls((prevBalls) => prevBalls + 1);
  };

  const handleBallDecrement = () => {
    if (balls > 0) {
      setBalls((prevBalls) => prevBalls - 1);
    }
  };

  // const handleOverIncrement = () => {
  //   setOvers((prevOvers) => prevOvers + 1);
  // };

  // const handleOverDecrement = () => {
  //   if (overs > 0) {
  //     setOvers((prevOvers) => prevOvers - 1);
  //   }
  // };

  return (
    <div className="App">
      <div className="scoreboard">
        <div className="balls">
          <p>Balls:</p>
          <button onClick={handleBallDecrement}>-</button>
          <input type="number" value={balls} onChange={(e) => setBalls(parseInt(e.target.value))} />
          <button onClick={handleBallIncrement}>+</button>
        </div>
        <div className="overs">
          <p>Overs:</p>
          {/* <button onClick={handleOverDecrement}>-</button> */}
          <input type="number" value={overs} onChange={(e) => setOvers(parseInt(e.target.value))} />
          {/* <button onClick={handleOverIncrement}>+</button> */}
        </div>
      </div>
    </div>
  );
}

export default App;
